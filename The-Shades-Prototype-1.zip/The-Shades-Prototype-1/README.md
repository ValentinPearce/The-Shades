The-Shades
==========

The Shades est un projet étudiant librement inspiré par Zork, un grand nom du jeu video textuel, et par le quartier mal famé
des "Ombres" de la ville fictive d'Ankh Morpork, issue de l'Univers du Disque-Monde de Terry Pratchett.

Pour le lancer, placez vous dans le répertoire du jeu et entrez la commande suivante dans votre terminal:

python The-Shades.py

Pour vous déplacer, les touches Z,Q,S et D correspondent respectivement aux direction Nord, Ouest, Sud et Est.
Vous pouvez avoir une description plus précise en appuyant sur la touche O.
Vous pouvez quitter le jeu grâce à la touche Esc ou Echap.

La version actuelle n'est que le premier prototype.
